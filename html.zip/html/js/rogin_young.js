document.getElementById("rogin_form").style.visibility = "hidden";
document.getElementById("rogin_nav").onclick = function () {
    document.getElementById("rogin_form").style.visibility = "visible";
}
document.getElementById("close_item").onclick = function () {
    document.getElementById("rogin_form").style.visibility = "hidden"
}
