// var rogin_nav =
// document.getElementById("rogin_nav");
// rogin_nav.addEventListener('click',function() {
//     anime({
//         targets: rogin_form,
//         visibility: visible
//     })
// })
// var close_item =
// document.getElementById("close_item");
// close_item.addEventListener('click',function() {
//     anime({
//         targets: rogin_form,
//         opacity: null
//     })
// })

